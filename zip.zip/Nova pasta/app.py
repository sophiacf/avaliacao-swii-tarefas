"""API-base da avaliação de SW II. Complete os TODOs."""
import os
from datetime import timedelta

from flask import Flask, jsonify, request
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
from werkzeug.security import check_password_hash, generate_password_hash


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.update(
        # Chave local de demonstração. Em produção, configure JWT_SECRET_KEY.
        JWT_SECRET_KEY=os.environ.get(
            "JWT_SECRET_KEY", "chave-didatica-local-sw-ii-nao-usar-em-producao"
        ),
        JWT_ACCESS_TOKEN_EXPIRES=timedelta(minutes=30),
    )
    if test_config:
        app.config.update(test_config)

    jwt = JWTManager(app)
    # Cada aplicação possui sua própria lista: os testes não compartilham dados.
    tarefas = [{"id": 1, "titulo": "Estudar Flask", "situacao": "pendente"}]
    usuarios = {
        "aluno": generate_password_hash("123456")
    }

    @jwt.unauthorized_loader
    def token_ausente(motivo):
        return jsonify({"erro": "Token de acesso ausente."}), 401

    @jwt.invalid_token_loader
    def token_invalido(motivo):
        return jsonify({"erro": "Token de acesso inválido."}), 401

    @jwt.expired_token_loader
    def token_expirado(header, payload):
        return jsonify({"erro": "Token de acesso expirado."}), 401

    @app.post("/login")
    def login():
        dados = request.get_json(silent=True)
        if not isinstance(dados, dict):
            return jsonify({"erro": "Envie um objeto JSON."}), 400

        usuario = dados.get("usuario")
        senha = dados.get("senha")
        if not isinstance(usuario, str) or not isinstance(senha, str):
            return jsonify({"erro": "Informe usuário e senha como texto."}), 400

       
        # Buscar o hash da senha do usuário
        senha_hash = usuarios.get(usuario)

        # Verificar se o usuário existe e a senha está correta
        if senha_hash is None or not check_password_hash(senha_hash, senha):
            return jsonify({"erro": "Usuário ou senha incorretos."}), 401

        # Gerar o token JWT
        token = create_access_token(identity=usuario)

        # Retornar o token para o usuário
        return jsonify({"access_token": token}), 200


    @app.get("/tarefas")
    def listar_tarefas():
        # Exemplo pronto para consultar durante a implementação.
        return jsonify(tarefas), 200

    @app.post("/tarefas")
    @jwt_required()
    def cadastrar_tarefa():
        dados = request.get_json(silent=True)

        # Verificar se os dados enviados são JSON
        if not isinstance(dados, dict):
            return jsonify({"erro": "Envie um objeto JSON."}), 400

        # Obter e validar o título
        titulo = dados.get("titulo")

        if not isinstance(titulo, str) or not titulo.strip():
            return jsonify({"erro": "O título é obrigatório."}), 400

        titulo = titulo.strip()

        # Gerar um identificador único
        novo_id = max(tarefa["id"] for tarefa in tarefas) + 1 if tarefas else 1

        # Criar a nova tarefa
        nova_tarefa = {
            "id": novo_id,
            "titulo": titulo,
            "situacao": "pendente"
        }

        # Adicionar a tarefa à lista
        tarefas.append(nova_tarefa)

        # Retornar a tarefa cadastrada
        return jsonify(nova_tarefa), 201


    return app


if __name__ == "__main__":
    create_app().run(debug=True)
