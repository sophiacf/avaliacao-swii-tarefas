# Atividade Avaliativa – Sistemas Web II

## Integrantes
- Sophia Cara Ferreira

## Sobre o projeto
Nesta atividade, completamos uma API de gerenciamento de tarefas usando Python e Flask.

A API permite fazer login, visualizar as tarefas cadastradas e adicionar novas tarefas. Para cadastrar uma tarefa, é necessário estar autenticado com um token JWT.

## Tecnologias utilizadas
- Python
- Flask
- JWT
- Pytest
- Bruno

## Como executar

Primeiro, abra a pasta do projeto no VS Code e execute os comandos abaixo no terminal.

**1. Criar o ambiente virtual:**

`py -m venv .venv`

**2. Instalar as bibliotecas:**

`.\.venv\Scripts\python.exe -m pip install -r requirements.txt`

**3. Iniciar a API:**

`.\.venv\Scripts\python.exe app.py`

A API ficará disponível em `http://127.0.0.1:5000`.

## Rotas da API

**POST /login**

Permite fazer login usando o usuário e a senha. Se estiverem corretos, a API retorna um token JWT.

Usuário de teste: `aluno`

Senha: `123456`

**GET /tarefas**

Mostra todas as tarefas cadastradas. Não precisa de autenticação.

**POST /tarefas**

Cadastra uma nova tarefa, mas exige um token JWT válido.

A tarefa precisa ter um título e, quando é criada, recebe um ID e a situação "pendente".

## Testes realizados

Usamos o Bruno para testar as rotas e o Pytest para verificar automaticamente se tudo estava funcionando.

Foram testados:
- Login com senha correta e incorreta.
- Consulta das tarefas.
- Cadastro sem token.
- Cadastro com token válido.
- Cadastro com título vazio ou ausente.

Para executar os testes:

`.\.venv\Scripts\python.exe -m pytest -v`

**Resultado: 8 testes passaram.**

## Print dos testes

![Resultado do Pytest](resultado-pytest.png)

## Observação

As tarefas ficam salvas apenas na memória, então são apagadas quando a API é reiniciada.