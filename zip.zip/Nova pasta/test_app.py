
import pytest
from app import create_app


# Configurar a aplicação para os testes
@pytest.fixture
def client():
    app = create_app({"TESTING": True})
    with app.test_client() as client:
        yield client


# Gerar um token válido para os testes
@pytest.fixture
def auth_headers(client):
    resposta = client.post(
        "/login",
        json={"usuario": "aluno", "senha": "123456"}
    )

    assert resposta.status_code == 200
    token = resposta.get_json()["access_token"]

    return {"Authorization": f"Bearer {token}"}


# TESTE 1 - Consultar tarefas
def test_consulta_tarefas(client):
    resposta = client.get("/tarefas")

    assert resposta.status_code == 200
    assert isinstance(resposta.get_json(), list)
    assert resposta.get_json()[0]["titulo"] == "Estudar Flask"


# TESTE 2 - Login com credenciais corretas
def test_login_correto(client):
    resposta = client.post(
        "/login",
        json={"usuario": "aluno", "senha": "123456"}
    )

    assert resposta.status_code == 200

    dados = resposta.get_json()
    assert "access_token" in dados
    assert isinstance(dados["access_token"], str)
    assert len(dados["access_token"]) > 0


# TESTE 3 - Login com senha incorreta
def test_login_senha_incorreta(client):
    resposta = client.post(
        "/login",
        json={"usuario": "aluno", "senha": "senhaerrada"}
    )

    assert resposta.status_code == 401
    assert "access_token" not in resposta.get_json()


# TESTE 4 - Cadastro sem token
def test_cadastro_sem_token(client):
    tarefas_antes = client.get("/tarefas").get_json()

    resposta = client.post(
        "/tarefas",
        json={"titulo": "Tarefa sem autenticação"}
    )

    assert resposta.status_code == 401

    tarefas_depois = client.get("/tarefas").get_json()
    assert tarefas_depois == tarefas_antes


# TESTE 5 - Cadastro com token válido
def test_cadastro_com_token(client, auth_headers):
    tarefas_antes = client.get("/tarefas").get_json()
    ids_anteriores = [tarefa["id"] for tarefa in tarefas_antes]

    resposta = client.post(
        "/tarefas",
        json={"titulo": "Nova tarefa de teste"},
        headers=auth_headers
    )

    assert resposta.status_code == 201

    dados = resposta.get_json()
    assert dados["titulo"] == "Nova tarefa de teste"
    assert dados["situacao"] == "pendente"
    assert isinstance(dados["id"], int)
    assert dados["id"] not in ids_anteriores

    tarefas_depois = client.get("/tarefas").get_json()

    assert len(tarefas_depois) == len(tarefas_antes) + 1
    assert dados in tarefas_depois


# TESTE 6 - Cadastro com título inválido
@pytest.mark.parametrize(
    "dados",
    [
        {},
        {"titulo": ""},
        {"titulo": "   "}
    ]
)
def test_cadastro_titulo_vazio(client, auth_headers, dados):
    tarefas_antes = client.get("/tarefas").get_json()

    resposta = client.post(
        "/tarefas",
        json=dados,
        headers=auth_headers
    )

    assert resposta.status_code == 400

    tarefas_depois = client.get("/tarefas").get_json()
    assert tarefas_depois == tarefas_antes
